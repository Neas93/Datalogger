#pragma once
#include <Arduino.h>
//Variabler til sensorerne 
struct SensorData {
    float temp1;
    float hum1;
    float temp2;
    float hum2;
    int light;
};
